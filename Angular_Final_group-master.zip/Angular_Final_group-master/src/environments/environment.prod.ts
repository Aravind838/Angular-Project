export const environment = {
  production: true,
  firebase : {
    
    apiKey: "AIzaSyAjEY4hfeFPOiqAPkOWKhz67l6wvzeoKr0",
    authDomain: "angularfirebase-62dab.firebaseapp.com",
    databaseURL: "https://angularfirebase-62dab.firebaseio.com",
    projectId: "angularfirebase-62dab",
    storageBucket: "angularfirebase-62dab.appspot.com",
    messagingSenderId: "605299160220"
     
    }
};
