export const myProducts:any = [
    { id: 0,
      name: 'T-shirt',
      cost: 1100,
      colour: 'red',
      size:'XXL'
     },
     { id: 1,
      name: 'Shirt',
      cost: 1200,
      colour: 'Brown',
      size:'XL'
     },
     { id: 2,
      name: 'T-shirt',
      cost: 1500,
      colour: 'White',
      size:'L'
     },
     { id: 3,
      name: 'T-shirt',
      cost: 1690,
      colour: 'White',
      size:'XXL'
     },
     { id: 4,
      name: 'Shirt',
      cost: 1800,
      colour: 'Brown',
      size:'M'
     },
     { id: 5,
      name: 'Kurta',
      cost: 1630,
      colour: 'Pink',
      size:'XXL'
     },
     { id: 6,
      name: 'Kurta',
      cost: 650,
      colour: 'Blue',
      size:'L'
     },
     { id: 7,
      name: 'Pant',
      cost: 900,
      colour: 'Brown',
      size:'XXL'
     },
      { id: 8,
      name: 'InnerCoat',
      cost: 3500,
      colour: 'Light Green',
      size:'XL'
     },
      { id: 9,
      name: 'Kurta',
      cost: 2500,
      colour: 'Red',
      size:'M'
     },
      { id: 10,
      name: 'Shirt',
      cost: 1500,
      colour: 'White',
      size:'XL'
     },
      { id: 11,
      name: 'T-shirt',
      cost: 1100,
      colour: 'Red',
      size:'XXL'
     },
      { id: 12,
      name: 'Kurta',
      cost: 1000,
      colour: 'White',
      size:'XXL'
     }, 
     { id: 13,
      name: 'Kurta',
      cost: 1000,
      colour: 'brown',
      size:'XL'
     }, 
     { id: 14,
      name: 'T-shirt',
      cost: 1400,
      colour: 'Yellow',
      size:'M'
     }
  ];