export interface Bike {
    key:string;
    name:string;
    ownername:string;
    price:string;
    url:string;

}
