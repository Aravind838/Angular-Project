export interface Mobile {
    key:string;
    name:string;
    ownername:string;
    price:string;
    url:string;

}
