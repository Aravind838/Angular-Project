export interface Car {
    key:string;
    name:string;
    ownername:string;
    price:string;
    url:string;

}
